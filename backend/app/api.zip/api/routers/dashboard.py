from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database.dependencies import get_db

from app.database.models.workflow import Workflow
from app.database.models.agent import Agent
from app.database.models.action import Action


router = APIRouter(
    prefix="/api/dashboard",
    tags=["dashboard"],
)


@router.get("/metrics")
def dashboard_metrics(
    db: Session = Depends(get_db),
):

    try:

        active_workflows = (
            db.query(Workflow)
            .filter(
                Workflow.status == "RUNNING"
            )
            .count()
        )


        agents_online = (
            db.query(Agent)
            .filter(
                Agent.status == "READY"
            )
            .count()
        )


        actions_executed = (
            db.query(Action)
            .count()
        )


        return {

            "active_workflows":
                active_workflows,

            "agents_online":
                agents_online,

            "actions_executed":
                actions_executed,

            "success_rate":
                100,

            "average_response_time":
                "1.2s",

        }


    except Exception as e:

        print(
            "DASHBOARD ERROR:",
            str(e)
        )

        raise HTTPException(
            status_code=500,
            detail=str(e),
        )